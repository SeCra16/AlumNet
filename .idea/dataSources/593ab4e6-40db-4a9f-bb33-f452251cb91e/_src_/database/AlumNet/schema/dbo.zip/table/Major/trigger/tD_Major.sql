CREATE TRIGGER tD_Major ON Major FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Major */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Major  Student on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="0001e42f", PARENT_OWNER="", PARENT_TABLE="Major"
    CHILD_OWNER="", CHILD_TABLE="Student"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_66", FK_COLUMNS="Major" */
    IF EXISTS (
        SELECT * FROM deleted,Student
        WHERE
          /*  %JoinFKPK(Student,deleted," = "," AND") */
          Student.Major = deleted.Field_of_Study
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Major because Student exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Major  Alumni on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Major"
    CHILD_OWNER="", CHILD_TABLE="Alumni"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_24", FK_COLUMNS="Job_Field" */
    IF EXISTS (
        SELECT * FROM deleted,Alumni
        WHERE
          /*  %JoinFKPK(Alumni,deleted," = "," AND") */
          Alumni.Job_Field = deleted.Field_of_Study
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Major because Alumni exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END