CREATE TRIGGER tD_Alumni ON Alumni FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Alumni */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Alumni  Connected on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00033122", PARENT_OWNER="", PARENT_TABLE="Alumni"
    CHILD_OWNER="", CHILD_TABLE="Connected"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_61", FK_COLUMNS="Alumni_Email" */
    IF EXISTS (
        SELECT * FROM deleted,Connected
        WHERE
          /*  %JoinFKPK(Connected,deleted," = "," AND") */
          Connected.Alumni_Email = deleted.Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Alumni because Connected exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Login  Alumni on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="Alumni"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_53", FK_COLUMNS="Email" */
    IF EXISTS (SELECT * FROM deleted,Login
    WHERE
      /* %JoinFKPK(deleted,Login," = "," AND") */
      deleted.Email = Login.Email AND
      NOT EXISTS (
          SELECT * FROM Alumni
          WHERE
            /* %JoinFKPK(Alumni,Login," = "," AND") */
            Alumni.Email = Login.Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Alumni because Login exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Major  Alumni on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Major"
    CHILD_OWNER="", CHILD_TABLE="Alumni"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_24", FK_COLUMNS="Job_Field" */
    IF EXISTS (SELECT * FROM deleted,Major
    WHERE
      /* %JoinFKPK(deleted,Major," = "," AND") */
      deleted.Job_Field = Major.Field_of_Study AND
      NOT EXISTS (
          SELECT * FROM Alumni
          WHERE
            /* %JoinFKPK(Alumni,Major," = "," AND") */
            Alumni.Job_Field = Major.Field_of_Study
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Alumni because Major exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END