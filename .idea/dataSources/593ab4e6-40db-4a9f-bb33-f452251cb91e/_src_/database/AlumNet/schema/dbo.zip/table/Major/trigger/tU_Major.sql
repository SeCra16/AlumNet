CREATE TRIGGER tU_Major ON Major FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on Major */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insField_of_Study varchar(50),
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Major  Student on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="00022fae", PARENT_OWNER="", PARENT_TABLE="Major"
      CHILD_OWNER="", CHILD_TABLE="Student"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_66", FK_COLUMNS="Major" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Field_of_Study)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Student
            WHERE
              /*  %JoinFKPK(Student,deleted," = "," AND") */
              Student.Major = deleted.Field_of_Study
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Major because Student exists.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Major  Alumni on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Major"
      CHILD_OWNER="", CHILD_TABLE="Alumni"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_24", FK_COLUMNS="Job_Field" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Field_of_Study)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Alumni
            WHERE
              /*  %JoinFKPK(Alumni,deleted," = "," AND") */
              Alumni.Job_Field = deleted.Field_of_Study
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Major because Alumni exists.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END