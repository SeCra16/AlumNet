CREATE TRIGGER tU_Connected ON Connected FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on Connected */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insAlumni_Email varchar(50),
    @insStudent_Email varchar(50),
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Connected  Messages on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="0003f382", PARENT_OWNER="", PARENT_TABLE="Connected"
      CHILD_OWNER="", CHILD_TABLE="Messages"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_36", FK_COLUMNS="Alumni_Email""Student_Email" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Alumni_Email) OR
    UPDATE(Student_Email)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Messages
            WHERE
              /*  %JoinFKPK(Messages,deleted," = "," AND") */
              Messages.Alumni_Email = deleted.Alumni_Email AND
              Messages.Student_Email = deleted.Student_Email
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Connected because Messages exists.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Student  Connected on child update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Student"
      CHILD_OWNER="", CHILD_TABLE="Connected"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_68", FK_COLUMNS="Student_Email" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Student_Email)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Student
        WHERE
          /* %JoinFKPK(inserted,Student) */
          inserted.Student_Email = Student.Email
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update Connected because Student does not exist.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Alumni  Connected on child update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Alumni"
      CHILD_OWNER="", CHILD_TABLE="Connected"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_61", FK_COLUMNS="Alumni_Email" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Alumni_Email)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Alumni
        WHERE
          /* %JoinFKPK(inserted,Alumni) */
          inserted.Alumni_Email = Alumni.Email
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update Connected because Alumni does not exist.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END