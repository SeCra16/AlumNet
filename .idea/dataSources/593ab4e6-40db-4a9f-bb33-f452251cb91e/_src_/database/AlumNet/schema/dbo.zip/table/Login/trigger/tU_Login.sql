CREATE TRIGGER tU_Login ON Login FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on Login */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insEmail varchar(50),
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Login  System_Admin on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="000302bb", PARENT_OWNER="", PARENT_TABLE="Login"
      CHILD_OWNER="", CHILD_TABLE="System_Admin"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_67", FK_COLUMNS="Email" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,System_Admin
            WHERE
              /*  %JoinFKPK(System_Admin,deleted," = "," AND") */
              System_Admin.Email = deleted.Email
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Login because System_Admin exists.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Login  Student on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
      CHILD_OWNER="", CHILD_TABLE="Student"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_64", FK_COLUMNS="Email" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Student
            WHERE
              /*  %JoinFKPK(Student,deleted," = "," AND") */
              Student.Email = deleted.Email
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Login because Student exists.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Login  Alumni on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
      CHILD_OWNER="", CHILD_TABLE="Alumni"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_53", FK_COLUMNS="Email" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Alumni
            WHERE
              /*  %JoinFKPK(Alumni,deleted," = "," AND") */
              Alumni.Email = deleted.Email
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Login because Alumni exists.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END