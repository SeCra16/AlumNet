CREATE TRIGGER tU_System_Admin ON System_Admin FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on System_Admin */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insEmail varchar(50),
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Login  System_Admin on child update no action */
    /* ERWIN_RELATION:CHECKSUM="00015dd2", PARENT_OWNER="", PARENT_TABLE="Login"
      CHILD_OWNER="", CHILD_TABLE="System_Admin"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_67", FK_COLUMNS="Email" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Login
        WHERE
          /* %JoinFKPK(inserted,Login) */
          inserted.Email = Login.Email
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update System_Admin because Login does not exist.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END