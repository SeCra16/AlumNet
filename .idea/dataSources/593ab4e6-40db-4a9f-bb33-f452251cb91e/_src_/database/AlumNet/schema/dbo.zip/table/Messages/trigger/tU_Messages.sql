CREATE TRIGGER tU_Messages ON Messages FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on Messages */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insMessage_ID integer,
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Connected  Messages on child update no action */
    /* ERWIN_RELATION:CHECKSUM="000196fb", PARENT_OWNER="", PARENT_TABLE="Connected"
      CHILD_OWNER="", CHILD_TABLE="Messages"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_36", FK_COLUMNS="Alumni_Email""Student_Email" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Alumni_Email) OR
    UPDATE(Student_Email)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Connected
        WHERE
          /* %JoinFKPK(inserted,Connected) */
          inserted.Alumni_Email = Connected.Alumni_Email and
          inserted.Student_Email = Connected.Student_Email
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update Messages because Connected does not exist.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END