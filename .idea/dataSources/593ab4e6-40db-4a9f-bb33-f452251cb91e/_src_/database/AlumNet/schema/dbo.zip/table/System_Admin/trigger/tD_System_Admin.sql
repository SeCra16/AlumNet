CREATE TRIGGER tD_System_Admin ON System_Admin FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on System_Admin */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Login  System_Admin on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00014628", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="System_Admin"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_67", FK_COLUMNS="Email" */
    IF EXISTS (SELECT * FROM deleted,Login
    WHERE
      /* %JoinFKPK(deleted,Login," = "," AND") */
      deleted.Email = Login.Email AND
      NOT EXISTS (
          SELECT * FROM System_Admin
          WHERE
            /* %JoinFKPK(System_Admin,Login," = "," AND") */
            System_Admin.Email = Login.Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last System_Admin because Login exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END