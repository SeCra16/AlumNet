CREATE TRIGGER tD_Login ON Login FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Login */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Login  System_Admin on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="0002bfb7", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="System_Admin"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_67", FK_COLUMNS="Email" */
    IF EXISTS (
        SELECT * FROM deleted,System_Admin
        WHERE
          /*  %JoinFKPK(System_Admin,deleted," = "," AND") */
          System_Admin.Email = deleted.Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Login because System_Admin exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Login  Student on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="Student"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_64", FK_COLUMNS="Email" */
    IF EXISTS (
        SELECT * FROM deleted,Student
        WHERE
          /*  %JoinFKPK(Student,deleted," = "," AND") */
          Student.Email = deleted.Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Login because Student exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Login  Alumni on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="Alumni"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_53", FK_COLUMNS="Email" */
    IF EXISTS (
        SELECT * FROM deleted,Alumni
        WHERE
          /*  %JoinFKPK(Alumni,deleted," = "," AND") */
          Alumni.Email = deleted.Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Login because Alumni exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END