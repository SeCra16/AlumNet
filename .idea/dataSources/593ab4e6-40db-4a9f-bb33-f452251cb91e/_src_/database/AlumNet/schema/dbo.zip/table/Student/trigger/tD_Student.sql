CREATE TRIGGER tD_Student ON Student FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Student */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Student  Connected on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="00031c3f", PARENT_OWNER="", PARENT_TABLE="Student"
    CHILD_OWNER="", CHILD_TABLE="Connected"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_68", FK_COLUMNS="Student_Email" */
    IF EXISTS (
        SELECT * FROM deleted,Connected
        WHERE
          /*  %JoinFKPK(Connected,deleted," = "," AND") */
          Connected.Student_Email = deleted.Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Student because Connected exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Major  Student on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Major"
    CHILD_OWNER="", CHILD_TABLE="Student"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_66", FK_COLUMNS="Major" */
    IF EXISTS (SELECT * FROM deleted,Major
    WHERE
      /* %JoinFKPK(deleted,Major," = "," AND") */
      deleted.Major = Major.Field_of_Study AND
      NOT EXISTS (
          SELECT * FROM Student
          WHERE
            /* %JoinFKPK(Student,Major," = "," AND") */
            Student.Major = Major.Field_of_Study
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Student because Major exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Login  Student on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
    CHILD_OWNER="", CHILD_TABLE="Student"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_64", FK_COLUMNS="Email" */
    IF EXISTS (SELECT * FROM deleted,Login
    WHERE
      /* %JoinFKPK(deleted,Login," = "," AND") */
      deleted.Email = Login.Email AND
      NOT EXISTS (
          SELECT * FROM Student
          WHERE
            /* %JoinFKPK(Student,Login," = "," AND") */
            Student.Email = Login.Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Student because Login exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END