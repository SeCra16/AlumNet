CREATE TRIGGER tD_Connected ON Connected FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Connected */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Connected  Messages on parent delete no action */
    /* ERWIN_RELATION:CHECKSUM="000373aa", PARENT_OWNER="", PARENT_TABLE="Connected"
    CHILD_OWNER="", CHILD_TABLE="Messages"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_36", FK_COLUMNS="Alumni_Email""Student_Email" */
    IF EXISTS (
        SELECT * FROM deleted,Messages
        WHERE
          /*  %JoinFKPK(Messages,deleted," = "," AND") */
          Messages.Alumni_Email = deleted.Alumni_Email AND
          Messages.Student_Email = deleted.Student_Email
    )
      BEGIN
        SELECT @errno  = 30001,
          @errmsg = 'Cannot delete Connected because Messages exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Student  Connected on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Student"
    CHILD_OWNER="", CHILD_TABLE="Connected"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_68", FK_COLUMNS="Student_Email" */
    IF EXISTS (SELECT * FROM deleted,Student
    WHERE
      /* %JoinFKPK(deleted,Student," = "," AND") */
      deleted.Student_Email = Student.Email AND
      NOT EXISTS (
          SELECT * FROM Connected
          WHERE
            /* %JoinFKPK(Connected,Student," = "," AND") */
            Connected.Student_Email = Student.Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Connected because Student exists.'
        GOTO error
      END

    /* ERwin Builtin Trigger */
    /* Alumni  Connected on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Alumni"
    CHILD_OWNER="", CHILD_TABLE="Connected"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_61", FK_COLUMNS="Alumni_Email" */
    IF EXISTS (SELECT * FROM deleted,Alumni
    WHERE
      /* %JoinFKPK(deleted,Alumni," = "," AND") */
      deleted.Alumni_Email = Alumni.Email AND
      NOT EXISTS (
          SELECT * FROM Connected
          WHERE
            /* %JoinFKPK(Connected,Alumni," = "," AND") */
            Connected.Alumni_Email = Alumni.Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Connected because Alumni exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END