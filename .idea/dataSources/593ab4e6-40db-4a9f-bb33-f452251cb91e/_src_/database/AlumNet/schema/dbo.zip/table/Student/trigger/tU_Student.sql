CREATE TRIGGER tU_Student ON Student FOR UPDATE AS
  /* ERwin Builtin Trigger */
  /* UPDATE trigger on Student */
  BEGIN
    DECLARE  @numrows int,
    @nullcnt int,
    @validcnt int,
    @insEmail varchar(50),
    @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)

    SELECT @numrows = @@rowcount
    /* ERwin Builtin Trigger */
    /* Student  Connected on parent update no action */
    /* ERWIN_RELATION:CHECKSUM="00039323", PARENT_OWNER="", PARENT_TABLE="Student"
      CHILD_OWNER="", CHILD_TABLE="Connected"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_68", FK_COLUMNS="Student_Email" */
    IF
    /* %ParentPK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        IF EXISTS (
            SELECT * FROM deleted,Connected
            WHERE
              /*  %JoinFKPK(Connected,deleted," = "," AND") */
              Connected.Student_Email = deleted.Email
        )
          BEGIN
            SELECT @errno  = 30005,
              @errmsg = 'Cannot update Student because Connected exists.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Major  Student on child update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Major"
      CHILD_OWNER="", CHILD_TABLE="Student"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_66", FK_COLUMNS="Major" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Major)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Major
        WHERE
          /* %JoinFKPK(inserted,Major) */
          inserted.Major = Major.Field_of_Study
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update Student because Major does not exist.'
            GOTO error
          END
      END

    /* ERwin Builtin Trigger */
    /* Login  Student on child update no action */
    /* ERWIN_RELATION:CHECKSUM="00000000", PARENT_OWNER="", PARENT_TABLE="Login"
      CHILD_OWNER="", CHILD_TABLE="Student"
      P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
      FK_CONSTRAINT="R_64", FK_COLUMNS="Email" */
    IF
    /* %ChildFK(" OR",UPDATE) */
    UPDATE(Email)
      BEGIN
        SELECT @nullcnt = 0
        SELECT @validcnt = count(*)
        FROM inserted,Login
        WHERE
          /* %JoinFKPK(inserted,Login) */
          inserted.Email = Login.Email
        /* %NotnullFK(inserted," IS NULL","select @nullcnt = count(*) from inserted where"," AND") */

        IF @validcnt + @nullcnt != @numrows
          BEGIN
            SELECT @errno  = 30007,
              @errmsg = 'Cannot update Student because Login does not exist.'
            GOTO error
          END
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END