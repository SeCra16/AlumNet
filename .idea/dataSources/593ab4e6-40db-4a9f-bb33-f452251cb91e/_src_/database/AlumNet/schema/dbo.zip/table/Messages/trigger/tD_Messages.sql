CREATE TRIGGER tD_Messages ON Messages FOR DELETE AS
  /* ERwin Builtin Trigger */
  /* DELETE trigger on Messages */
  BEGIN
    DECLARE  @errno   int,
    @severity int,
    @state    int,
    @errmsg  varchar(255)
    /* ERwin Builtin Trigger */
    /* Connected  Messages on child delete no action */
    /* ERWIN_RELATION:CHECKSUM="0001916c", PARENT_OWNER="", PARENT_TABLE="Connected"
    CHILD_OWNER="", CHILD_TABLE="Messages"
    P2C_VERB_PHRASE="", C2P_VERB_PHRASE="",
    FK_CONSTRAINT="R_36", FK_COLUMNS="Alumni_Email""Student_Email" */
    IF EXISTS (SELECT * FROM deleted,Connected
    WHERE
      /* %JoinFKPK(deleted,Connected," = "," AND") */
      deleted.Alumni_Email = Connected.Alumni_Email AND
      deleted.Student_Email = Connected.Student_Email AND
      NOT EXISTS (
          SELECT * FROM Messages
          WHERE
            /* %JoinFKPK(Messages,Connected," = "," AND") */
            Messages.Alumni_Email = Connected.Alumni_Email AND
            Messages.Student_Email = Connected.Student_Email
      )
    )
      BEGIN
        SELECT @errno  = 30010,
          @errmsg = 'Cannot delete last Messages because Connected exists.'
        GOTO error
      END


    /* ERwin Builtin Trigger */
    RETURN
    error:
    RAISERROR (@errmsg, -- Message text.
    @severity, -- Severity (0~25).
    @state) -- State (0~255).
    rollback transaction
  END